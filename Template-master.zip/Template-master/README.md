# Заготовка для верстки макетов

## Как работать? Краткая пошаговая инструкция.
1. Создайте свой репозиторий для верстки данного макета
2. Склонируйте текущий репозиторий
3. Удалите файл README.md и переименуйте файл README.tmp в README.md
4. Выполните Commit всех своих изменений и сделайте Push в свой репозиторий
5. Включите **GitHub Pages**
6. Отправьте ссылку боту на **GitHub репозиторий**
7. Готово

[Инструкцию "Как работать с Git"](https://figmatohtml.notion.site/Git-4f6201ace2ae4f109cc3ec74feb1961b)

[Инструкцию "Функция GitHub Pages"](https://figmatohtml.notion.site/GitHub-Pages-6266e77074274a728ace3bb60b355986)

[Правила](https://figmatohtml.notion.site/7d3e52a516734f99935b08c56d3d7d50)
